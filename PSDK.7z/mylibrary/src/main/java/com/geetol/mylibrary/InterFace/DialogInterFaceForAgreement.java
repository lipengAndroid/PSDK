package com.geetol.mylibrary.InterFace;

public interface DialogInterFaceForAgreement {
    void ok();
}
