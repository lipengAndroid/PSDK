package com.geetol.mylibrary.Entity;

public class KEY {
    public final static String LANGUAGE = "LANGUAGE";

    public static final String TOKEN = "TOKEN";//asa

    public static final String MAIN = "main";

    public static final String SONG_LIST = "SONG_LIST";

    public static final String TYPE = "TYPE";

    public static final String ONE_START = "ONE_START";

    public static final String URI = "URI";

    public static final String TITLE = "TITLE";

    public static final String IS_CLOSE = "IS_CLOSE";

    public static final int ADD = 2222;//添加图片

    public static final int REPLACE = 1111;//替换图片

    public static String alarmClockTimeH = "alarmClockTimeH";//闹钟时间 小时

    public static String alarmClockTimeM = "alarmClockTimeM";//闹钟时间 分钟

    public static String alarmClockTimeTv = "alarmClockTimeTv";//闹钟时间

    public static String AlarmSwitch = "AlarmSwitch";//闹钟开关

    public static String sleepLength = "sleepLength";

}
